import numpy as np 
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import copy
from torchvision import transforms
from PIL import Image
import torch.nn.functional as F
import random
import time
import psutil

start_time = time.time()
if __name__ == "__main__":
    print("Script is starting...")

class Attacker():
    def __init__(self, model, img_attacker, txt_attacker):
        self.model = model
        self.img_attacker = img_attacker
        self.txt_attacker = txt_attacker

    def attack(self, imgs, txts, txt2img, device='cpu', max_length=30, scales=None, masks=None, **kwargs):
        start_time = time.time()  # 开始计时
        with torch.no_grad():
            origin_img_output = self.model.inference_image(self.img_attacker.normalization(imgs))
            img_supervisions = origin_img_output['image_feat'][txt2img] 
        adv_txts = self.txt_attacker.img_guided_attack(self.model, txts, img_embeds=img_supervisions)

        with torch.no_grad():
            txts_input = self.txt_attacker.tokenizer(adv_txts, padding='max_length', truncation=True, max_length=max_length, return_tensors="pt").to(device)
            txts_output = self.model.inference_text(txts_input)
            txt_supervisions = txts_output['text_feat']
        
        adv_imgs, last_adv_imgs = self.img_attacker.txt_guided_attack(self.model, imgs, txt2img, device, scales=scales, txt_embeds=txt_supervisions)
        
        
        self.img_attacker.show_perturbation(imgs, adv_imgs, title="Adversarial Perturbation")
        
        with torch.no_grad():
            adv_imgs_outputs = self.model.inference_image(self.img_attacker.normalization(adv_imgs))
            adv_img_supervisions = adv_imgs_outputs['image_feat'][txt2img]
            last_adv_imgs_outputs = self.model.inference_image(self.img_attacker.normalization(last_adv_imgs))
            last_adv_img_supervisions = last_adv_imgs_outputs['image_feat'][txt2img]
        adv_txts = self.txt_attacker.img_guided_attack(self.model, txts, img_embeds=img_supervisions,
                                        adv_img_embeds=adv_img_supervisions, last_adv_img_embeds=last_adv_img_supervisions)     
        end_time = time.time()  # 结束计时
        execuate_time = end_time - start_time  
        return adv_imgs, adv_txts, execuate_time  

class ImageAttacker():
    def __init__(self, normalization, eps=8/255, steps=20, step_size=0.5/255, sample_numbers=5, momentum=0.9):
        self.normalization = normalization
        self.eps = eps
        self.steps = steps 
        self.step_size = step_size
        self.sample_numbers = sample_numbers
        self.momentum = momentum
        self.velocity = 0  
        self.gradient_aggregator = SpatialGradientAggregator()  

    def loss_func(self, adv_imgs_embeds, txts_embeds, txt2img):  
        device = adv_imgs_embeds.device    

        it_sim_matrix = adv_imgs_embeds @ txts_embeds.T
        it_labels = torch.zeros(it_sim_matrix.shape).to(device)
        
        for i in range(len(txt2img)):
            it_labels[txt2img[i], i] = 1
        
        loss_IaTcpos = -(it_sim_matrix * it_labels).sum(-1).mean()
        loss = loss_IaTcpos
        
        return loss
    
    def rand3Num(self):
        while True:
            num1 = random.randint(1, 100)
            if 100 - num1 > 1:
                num2 = random.randint(1, 100 - num1)
            else:
                num1 = 98
                num2 = 1
            num3 = 100 - num1 - num2
    
            if 1 <= num3 <= 100:
                break

        return (num1, num2, num3)
   
    def txt_guided_attack(self, model, imgs, txt2img, device, scales=None, txt_embeds=None):
        model.eval()
        
        b, _, _, _ = imgs.shape
        scales_num = len(scales) + 1 if scales else 1

        adv_imgs = imgs.detach() + torch.from_numpy(np.random.uniform(-self.eps, self.eps, imgs.shape)).float().to(device)
        adv_imgs = torch.clamp(adv_imgs, 0.0, 1.0)

        last_adv_imgs = None
        ratio_list = []

        for step in range(self.steps):
            if last_adv_imgs is not None:
                adv_imgs, last_adv_imgs = self._attack_step(model, imgs, adv_imgs, last_adv_imgs, txt_embeds, txt2img, device, scales, b)
                ratio_list.append(self._sample_best_ratio())
            else:
                last_adv_imgs = adv_imgs.clone()
                adv_imgs = self._first_attack_step(model, adv_imgs, imgs, txt_embeds, txt2img, device, scales, b)

        return adv_imgs, last_adv_imgs

    def _attack_step(self, model, imgs, adv_imgs, last_adv_imgs, txt_embeds, txt2img, device, scales, batch_size):
        samples = [self.rand3Num() for _ in range(self.sample_numbers)]
        best_loss = float('-inf')
        best_adv_img = None

        for sample in samples:
            mixed_img = self._mix_images(adv_imgs, imgs, last_adv_imgs, sample)
            loss = self._calculate_loss(model, mixed_img, txt_embeds, txt2img, device, scales, batch_size)
            if loss > best_loss:
                best_loss = loss
                best_adv_img = mixed_img
        
        
        grad = self.gradient_aggregator.compute_aggregated_gradient(best_adv_img, txt_embeds, txt2img, model, device)
        self.velocity = self.momentum * self.velocity + grad  
        self.step_size = self._adaptive_step_size(grad)  
        adv_imgs = self._update_adv_img(best_adv_img, self.velocity, imgs)

        return adv_imgs, last_adv_imgs

    def _first_attack_step(self, model, adv_imgs, imgs, txt_embeds, txt2img, device, scales, batch_size):
        scaled_imgs = self.get_scaled_imgs(adv_imgs, scales, device)
        loss = self._calculate_loss(model, scaled_imgs, txt_embeds, txt2img, device, scales, batch_size)
        grad = self.gradient_aggregator.compute_aggregated_gradient(adv_imgs, txt_embeds, txt2img, model, device)  
        self.velocity = self.momentum * self.velocity + grad  
        adv_imgs = self._update_adv_img(adv_imgs, self.velocity, imgs)
        return adv_imgs

    def _mix_images(self, adv_imgs, imgs, last_adv_imgs, sample):
        return (sample[0] / 100) * adv_imgs + (sample[1] / 100) * imgs + (sample[2] / 100) * last_adv_imgs

    def _calculate_loss(self, model, adv_imgs, txt_embeds, txt2img, device, scales, batch_size):
        scaled_imgs = self.get_scaled_imgs(adv_imgs, scales, device)
        adv_imgs_output = model.inference_image(self.normalization(scaled_imgs))
        adv_imgs_embeds = adv_imgs_output['image_feat']
        loss = self.loss_func(adv_imgs_embeds, txt_embeds, txt2img)
        return loss

    def _update_adv_img(self, adv_imgs, grad, imgs):
        perturbation = self.step_size * grad.sign()
        adv_imgs = adv_imgs.detach() + perturbation
        adv_imgs = torch.min(torch.max(adv_imgs, imgs - self.eps), imgs + self.eps)
        return torch.clamp(adv_imgs, 0.0, 1.0)

    def _adaptive_step_size(self, grad):
        grad_norm = torch.norm(grad)
        return min(self.step_size * (1 + grad_norm / 10), 1.0 / 255)  

    def _sample_best_ratio(self):
        samples = [self.rand3Num() for _ in range(self.sample_numbers)]
        best_sample = max(samples, key=lambda x: sum(x))
        return best_sample

    
    def show_perturbation(self, original_imgs, adv_imgs, title="Adversarial Perturbation"):
        
        perturbation = adv_imgs - original_imgs

        
        perturbation = perturbation.detach().squeeze(0).cpu().numpy()
        perturbation = np.transpose(perturbation, (1, 2, 0))
        perturbation = (perturbation - perturbation.min()) / (perturbation.max() - perturbation.min())  

        
        plt.imshow(perturbation)
        plt.title(title)
        plt.axis('off')
        plt.show()

    def save_img(self, img_name, norm_img):
        pil_array = (norm_img * 255).to(torch.uint8).cpu().numpy()
        pil_img = Image.fromarray(np.transpose(pil_array, (1, 2, 0)))
        img_path = "./mscoco_imgs/"
        pil_img.save(img_path + img_name)

    def get_scaled_imgs(self, imgs, scales=None, device='cuda'):
        if scales is None:
            return imgs

        ori_shape = (imgs.shape[-2], imgs.shape[-1])
        reverse_transform = transforms.Resize(ori_shape, interpolation=transforms.InterpolationMode.BICUBIC)
        result = []
        for ratio in scales:
            scale_shape = (int(ratio * ori_shape[0]), int(ratio * ori_shape[1]))
            scale_transform = transforms.Resize(scale_shape, interpolation=transforms.InterpolationMode.BICUBIC)
            scaled_imgs = imgs + torch.from_numpy(np.random.normal(0.0, 0.05, imgs.shape)).float().to(device)
            scaled_imgs = scale_transform(scaled_imgs)
            scaled_imgs = torch.clamp(scaled_imgs, 0.0, 1.0)
            reversed_imgs = reverse_transform(scaled_imgs)
            result.append(reversed_imgs)

        return torch.cat([imgs,] + result, 0)

class SpatialGradientAggregator:
    def __init__(self, eps=8/255, sample_size=5, gradient_threshold=0.1):
        self.eps = eps
        self.sample_size = sample_size
        self.gradient_threshold = gradient_threshold

    def compute_aggregated_gradient(self, image, txt_embeds, txt2img, model, device):
        
        sampled_images = self._sample_neighborhood(image, device)
        
        
        gradients = self._compute_gradients(sampled_images, txt_embeds, txt2img, model, device)

        
        selected_gradients = [g for g in gradients if g.norm() > self.gradient_threshold]

        
        if selected_gradients:
            aggregated_gradient = torch.mean(torch.stack(selected_gradients), dim=0)
        else:
            aggregated_gradient = torch.mean(gradients, dim=0)

        return aggregated_gradient

    def _sample_neighborhood(self, image, device):
        
        sampled_images = []
        for _ in range(self.sample_size):
            noise = torch.from_numpy(np.random.uniform(-self.eps, self.eps, image.shape)).float().to(device)
            sampled_image = torch.clamp(image + noise, 0.0, 1.0)
            sampled_images.append(sampled_image)
        return torch.stack(sampled_images)

    def _compute_gradients(self, images, txt_embeds, txt2img, model, device):
    
        # 确保 images 是叶子节点且设置了 requires_grad=True
        if not images.is_leaf:
            images = images.detach().clone().requires_grad_(True)
        else:
            images.requires_grad_(True)

        # 检查输入形状是否正确并进行必要调整
        #print(f"Original image shape: {images.shape}")
        if images.dim() == 5:  # (B, 1, C, H, W) 的情况
            images = images.view(images.shape[0] * images.shape[1], images.shape[2], images.shape[3], images.shape[4])  # 转为 (B, C, H, W)
        #print(f"Adjusted image shape: {images.shape}")

        # 不使用 torch.no_grad()，确保梯度传播
        adv_imgs_output = model.inference_image(images)  # 确保这个调用支持梯度计算
        adv_imgs_embeds = adv_imgs_output['image_feat'][txt2img]

        loss = self._calculate_loss(adv_imgs_embeds, txt_embeds, txt2img, device)

        # 计算梯度
        gradients = torch.autograd.grad(loss, images, create_graph=True, retain_graph=True)[0]
        return gradients



    def _calculate_loss(self, adv_imgs_embeds, txt_embeds, txt2img, device):
        """计算损失函数用于梯度计算"""
        it_sim_matrix = adv_imgs_embeds @ txt_embeds.T
        it_labels = torch.zeros(it_sim_matrix.shape).to(device)
        
        for i in range(len(txt2img)):
            it_labels[txt2img[i], i] = 1
        
        loss_IaTcpos = -(it_sim_matrix * it_labels).sum(-1).mean()
        loss = loss_IaTcpos
        
        return loss


filter_words = ['a', 'about', 'above', 'across', 'after', 'afterwards', 'again', 'against', 'ain', 'all', 'almost',
                'alone', 'along', 'already', 'also', 'although', 'am', 'among', 'amongst', 'an', 'and', 'another',
                'any', 'anyhow', 'anyone', 'anything', 'anyway', 'anywhere', 'are', 'aren', "aren't", 'around', 'as',
                'at', 'back', 'been', 'before', 'beforehand', 'behind', 'being', 'below', 'beside', 'besides',
                'between', 'beyond', 'both', 'but', 'by', 'can', 'cannot', 'could', 'couldn', "couldn't", 'd', 'didn',
                "didn't", 'doesn', "doesn't", 'don', "don't", 'down', 'due', 'during', 'either', 'else', 'elsewhere',
                'empty', 'enough', 'even', 'ever', 'everyone', 'everything', 'everywhere', 'except', 'first', 'for',
                'former', 'formerly', 'from', 'hadn', "hadn't", 'hasn', "hasn't", 'haven', "haven't", 'he', 'hence',
                'her', 'here', 'hereafter', 'hereby', 'herein', 'hereupon', 'hers', 'herself', 'him', 'himself', 'his',
                'how', 'however', 'hundred', 'i', 'if', 'in', 'indeed', 'into', 'is', 'isn', "isn't", 'it', "it's",
                'its', 'itself', 'just', 'latter', 'latterly', 'least', 'll', 'may', 'me', 'meanwhile', 'mightn',
                "mightn't", 'mine', 'more', 'moreover', 'most', 'mostly', 'must', 'mustn', "mustn't", 'my', 'myself',
                'namely', 'needn', "needn't", 'neither', 'never', 'nevertheless', 'next', 'no', 'nobody', 'none',
                'noone', 'nor', 'not', 'nothing', 'now', 'nowhere', 'o', 'of', 'off', 'on', 'once', 'one', 'only',
                'onto', 'or', 'other', 'others', 'otherwise', 'our', 'ours', 'ourselves', 'out', 'over', 'per',
                'please', 's', 'same', 'shan', "shan't", 'she', "she's", "should've", 'shouldn', "shouldn't", 'somehow',
                'something', 'sometime', 'somewhere', 'such', 't', 'than', 'that', "that'll", 'the', 'their', 'theirs',
                'them', 'themselves', 'then', 'thence', 'there', 'thereafter', 'thereby', 'therefore', 'therein',
                'thereupon', 'these', 'they', 'this', 'those', 'through', 'throughout', 'thru', 'thus', 'to', 'too',
                'toward', 'towards', 'under', 'unless', 'until', 'up', 'upon', 'used', 've', 'was', 'wasn', "wasn't",
                'we', 'were', 'weren', "weren't", 'what', 'whatever', 'when', 'whence', 'whenever', 'where',
                'whereafter', 'whereas', 'whereby', 'wherein', 'whereupon', 'wherever', 'whether', 'which', 'while',
                'whither', 'who', 'whoever', 'whole', 'whom', 'whose', 'why', 'with', 'within', 'without', 'won',
                "won't", 'would', 'wouldn', "wouldn't", 'y', 'yet', 'you', "you'd", "you'll", "you're", "you've",
                'your', 'yours', 'yourself', 'yourselves', '.', '-', 'a the', '/', '?', 'some', '"', ',', 'b', '&', '!',
                '@', '%', '^', '*', '(', ')', "-", '-', '+', '=', '<', '>', '|', ':', ";", '～', '·']
filter_words = set(filter_words)
    


class TextAttacker:
    def __init__(self, ref_net, tokenizer, cls=True, max_length=30, number_perturbation=1, topk=10, threshold_pred_score=0.3, batch_size=4, text_ratios=[0.6,0.2,0.2], filter_words=None):
        self.ref_net = ref_net
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.number_perturbation = number_perturbation
        self.threshold_pred_score = threshold_pred_score
        self.topk = topk
        self.batch_size = batch_size
        self.cls = cls
        self.text_ratios = text_ratios
        self.filter_words = set(filter_words) if filter_words else set()
         # 从 transformers 库中加载预训练的 BERT 模型和 tokenizer
        from transformers import BertTokenizer, BertForMaskedLM

        model_name = 'bert-base-uncased'
        tokenizer = BertTokenizer.from_pretrained(model_name)
        ref_net = BertForMaskedLM.from_pretrained(model_name)
    
    #def _tokenize(self, text):
        #words = text.split(' ')
        #sub_words = []
        #for word in words:
            #sub_words.extend(self.tokenizer.tokenize(word))  # 对每个单词分别进行分词并扩展到 sub_words 列表
        #keys = [(len(sub_words[:i]), len(sub_words[:i+1])) for i in range(len(sub_words)-1)]
        #return words, sub_words, keys
    def _tokenize(self, text):
        words = text.split(' ')
        sub_words = self.tokenizer.tokenize(text)  # 修改这里，传递字符串而不是列表
        keys = [(len(sub_words[:i]), len(sub_words[:i+1])) for i in range(len(sub_words)-1)]
        return words,  keys
  
    

    def _get_masked_text(self, words, index):
        masked_words = words[:index] + ['[MASK]'] + words[index + 1:]
        return ' '.join(masked_words)

    def get_important_scores(self, text, net, origin_embeds, batch_size, max_length):
        device = origin_embeds.device
        #words, _, keys = self._tokenize(text)  
        words, keys = self._tokenize(text)  # 如果不需要使用 sub_words，可以这样获取 words 和 keys
        important_scores = []
        for idx in range(len(words)):
            masked_text = self._get_masked_text(words, idx)
            masked_text_input = self.tokenizer(
                masked_text,
                return_tensors='pt',
                padding='max_length',
                truncation=True,
                max_length=max_length
            ).to(device)
            masked_output = net.inference_text(masked_text_input)
            masked_embed = self._get_embedding(masked_output)
            
            score = nn.KLDivLoss(reduction='sum')(masked_embed, origin_embeds)
            important_scores.append(score.item())
        return important_scores

    
    def _get_embedding(self, output):
        if isinstance(output, dict) and 'text_feat' in output:
            return output['text_feat']  # 直接返回 'text_feat' 对应的张量
        else:
            raise ValueError("The output must be a dictionary with a 'text_feat' key.")
    
   
    
    def select_best_substitute(self, word, text, substitutes, net, tokenizer, device, max_length):
        best_substitute = word
        best_score = 0

        # 将原始文本转换为模型的输入格式并获取嵌入表示
        origin_inputs = tokenizer(text, return_tensors='pt', padding='max_length', truncation=True, max_length=max_length).to(device)
        origin_output = net.inference_text(origin_inputs)
        origin_embeds = self._get_embedding(origin_output)

        
        for idx in substitutes:
            
            if idx.dim() == 0:  
                substitute = tokenizer._convert_id_to_token(idx.item())
            else:  
                substitute = [tokenizer._convert_id_to_token(i.item()) for i in idx]

            
            if isinstance(substitute, list):
                substitute = substitute[0]  

            
            modified_text = text.replace(word, substitute, 1)

            
            modified_inputs = tokenizer(modified_text, return_tensors='pt', padding='max_length', truncation=True, max_length=max_length).to(device)
            modified_output = net.inference_text(modified_inputs)
            modified_embed = self._get_embedding(modified_output)

            
            score = (modified_embed * origin_embeds).sum(1).mean().item()

            
            if score > best_score:
                best_score = score
                best_substitute = substitute

        return best_substitute



        

    def img_guided_attack(self, net, texts, img_embeds=None, adv_img_embeds=None, last_adv_img_embeds=None):
        device = self.ref_net.device
        text_inputs = self.tokenizer(texts, padding='max_length', truncation=True, max_length=self.max_length, return_tensors='pt').to(device)

        mlm_logits = self.ref_net(text_inputs.input_ids, attention_mask=text_inputs.attention_mask).logits
        word_pred_scores_all, word_predictions = torch.topk(mlm_logits, self.topk, -1)

        origin_output = net.inference_text(text_inputs)
        if self.cls:
            origin_embeds = origin_output['text_feat'][:, 0, :].detach()
        else:
            origin_embeds = origin_output['text_feat'].flatten(1).detach()

        final_adverse = []
        for i, text in enumerate(texts):
            important_scores = self.get_important_scores(text, net, origin_embeds[i], self.batch_size, self.max_length)
            list_of_index = sorted(enumerate(important_scores), key=lambda x: x[1], reverse=True)
            words, keys = self._tokenize(text) 
            #words, sub_words, keys = self._tokenize(text)
            final_words = copy.deepcopy(words)
            change = 0

            for top_index in list_of_index:
                if change >= self.number_perturbation:
                    break

                tgt_word = words[top_index[0]]
                if tgt_word in self.filter_words or keys[top_index[0]][0] > self.max_length - 2:
                    continue

                substitute = self.select_best_substitute(tgt_word, text, word_predictions[i, keys[top_index[0]][0]:keys[top_index[0]][1]], net, self.tokenizer, device, self.max_length)
                if substitute != tgt_word:
                    final_words[keys[top_index[0]][0]] = substitute
                    change += 1

            final_text = ' '.join(final_words)
            final_adverse.append(final_text)

        return final_adverse

end_time = time.time()
print("Execution time:", end_time - start_time, "seconds")
print("Script has finished.")


import psutil

mem = psutil.virtual_memory()
print(mem.percent)  # 打印当前内存占用百分比