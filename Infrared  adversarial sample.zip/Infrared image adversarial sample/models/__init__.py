from .clip_model import clip
